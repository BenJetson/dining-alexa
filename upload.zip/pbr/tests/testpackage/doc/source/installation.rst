============
Installation
============

At the command line::

    $ pip install testpackage

Or, if you have virtualenvwrapper installed::

    $ mkvirtualenv testpackage
    $ pip install testpackage
